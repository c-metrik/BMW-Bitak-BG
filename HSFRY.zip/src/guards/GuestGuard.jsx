import { Navigate, Outlet } from "react-router";
import { useAuth } from "../contexts/AuthContext";

export default function GuestGuard() {
    const { isAuthenticated, isInitializing } = useAuth();

    if (isInitializing) {
        return null;
    }

    if (isAuthenticated) {
        return <Navigate to="/" replace />;
    }

    return <Outlet />;
}